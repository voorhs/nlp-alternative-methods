---
marp: true
paginate: true
math: true
---

<style>
img[alt~="center"] {
  display: block;
  margin: 0 auto;
}
section::after {
  content: attr(data-marpit-pagination) '/' attr(data-marpit-pagination-total);
}
</style>

# Time Series Analysis Using Deep Learning Methods

**Report, Alexeev Ilya, 517**

###### Moscow, Nov 28, 2024

---

## Outline

- Problem statement
- Neural Networks Primitives for Time Series
- Architectures

---

## Problem Statement. TS Definition

Let us call $x_1,\ldots,x_T$ univariate time series, if $x_t\in\mathbb{R}$. 
- $x_t$ is *observation*
- $t$ is timestamp
- if $x_t\in\mathbb{R}^n$, the time series is called *multivariate*

---

## Problem Statement. Tasks of TS Analysis

![center height:500](figures/tasks.jpg)

---

## NN Privitives For TS Analysis

![center height:500](figures/transformer-forecasting.jpg)

---

## Modern Architectures. Problems

- Periodicity (TimesNet)
- Non-stationarity (AutoFormer)
- Normalization (RevIN, NST)

---

## Non-stationarity

![center height:500](figures/stationarity.jpg)

---

## AutoFormer. Component Decomposition

$$
\begin{align}
x_\text{trend} &= \text{MovAvg}(\text{Padding}(x)), \\
x_\text{season} &= x-x_\text{season}
\end{align}
$$

---

## Conclusion

To perform TS analysis one should address the domain's specifics and design appropriate architecture using NN primitives. 

Get your feet in hand and run to analyze time series!

---

## References

- Zhou et al. [Informer: Beyond Efficient Transformer for Long Sequence Time-Series Forecasting](https://arxiv.org/abs/2012.07436). 2021.

- Liu et al. [Non-stationary Transformers: Exploring the Stationarity in Time Series Forecasting](https://arxiv.org/abs/2205.14415). 2023.

- Wu et al. [TimesNet: Temporal 2D-variation modeling for general time series analysis](https://arxiv.org/abs/2210.02186). arXiv preprint arXiv:2210.02186, 2023.

- Wu et al. [Autoformer: Decomposition transformers with auto-correlation for long-term series forecasting](https://arxiv.org/abs/2106.13008). arXiv preprint arXiv:2106.13008, 2022.

- Kim et al. [Reversible instance normalization for accurate time-series forecasting against distribution shift](https://openreview.net/forum?id=cGDAkQo1C0p). In *International Conference on Learning Representations*, 2022.
